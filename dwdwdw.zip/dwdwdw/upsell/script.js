// ===== UPSELL - PIX GATEWAY INTEGRATION =====
const qs = (s, r = document) => r.querySelector(s);
const STORAGE_KEY = 'gateway_config';
let currentTxId = '';
let pollingInterval = null;

function getGatewayConfig() {
    if (typeof GLOBAL_CONFIG !== 'undefined') {
        return GLOBAL_CONFIG;
    }
    return null;
}

function amountToCents(amountStr) {
    const clean = amountStr.replace(/[^\d,\.]/g, '').replace(',', '.');
    return Math.round(parseFloat(clean) * 100);
}

function btoa_utf8(str) {
    return btoa(unescape(encodeURIComponent(str)));
}

// Get customer data saved from checkout
function getCustomerData() {
    try {
        const saved = localStorage.getItem('checkout_customer');
        if (saved) return JSON.parse(saved);
    } catch (e) { }
    return { name: "Cliente", email: "cliente@email.com", cpf: "52998224725", phone: "11999999999" };
}

// ===== INIT VALUES FROM PANEL =====
(function init() {
    const config = getGatewayConfig();
    const amount = config?.upsell?.amount || '78,25';
    const uiPrice = qs('#upsell-value');
    if (uiPrice) uiPrice.textContent = 'R$ ' + amount;
    const heading = config?.upsell?.name || 'Pagamento da Taxa Obrigatória';

    document.getElementById('upsell-value').textContent = 'R$ ' + amount;
    document.getElementById('upsell-heading').textContent = heading;
})();

// ===== GATEWAY: IRONPAY (idêntico ao checkout) =====
async function createPixIronPay(config, customerData, amountCents, productName) {
    const creds = config.gateways.ironpay;
    if (!creds.offer_hash || !creds.product_hash) {
        throw new Error('IronPay requer Offer Hash e Product Hash. Preencha no painel.');
    }
    const url = `${API_BASES.ironpay}/api/public/v1/transactions?api_token=${encodeURIComponent(creds.token)}`;
    const body = {
        amount: amountCents,
        offer_hash: creds.offer_hash,
        payment_method: "pix",
        customer: {
            name: customerData.name,
            email: customerData.email,
            phone_number: customerData.phone,
            document: customerData.cpf,
            street_name: "Rua Principal",
            number: "1",
            complement: "",
            neighborhood: "Centro",
            city: "São Paulo",
            state: "SP",
            zip_code: "01001000"
        },
        cart: [{
            product_hash: creds.product_hash,
            title: productName,
            cover: null,
            price: amountCents,
            quantity: 1,
            operation_type: 1,
            tangible: false
        }],
        expire_in_days: 1,
        transaction_origin: "api"
    };
    const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(body)
    });
    if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.message || `Erro IronPay: ${response.status}`);
    }
    const data = await response.json();
    console.log('IronPay response:', data);
    let pixCopyPaste = data?.pix?.pix_qr_code || data?.pix?.qrcode || data?.pix?.qr_code || data?.qrcode || null;
    let qrCodeUrl = data?.pix?.pix_url || data?.pix?.qr_code_url || null;
    return { pixCopyPaste, qrCodeUrl, raw: data };
}

// ===== GATEWAY: ACTIVEPAY (idêntico ao checkout) =====
async function createPixActivePay(config, customerData, amountCents, productName) {
    const creds = config.gateways.activepay;
    const auth = 'Basic ' + btoa_utf8(creds.public_key + ':' + creds.secret_key);
    const body = {
        amount: amountCents,
        paymentMethod: "pix",
        customer: {
            name: customerData.name,
            email: customerData.email,
            phone: customerData.phone,
            document: {
                number: customerData.cpf,
                type: "cpf"
            }
        },
        items: [{
            title: productName,
            unitPrice: amountCents,
            quantity: 1,
            tangible: false,
            externalRef: "checkout-pix"
        }],
        pix: {
            expiresInDays: 1
        }
    };
    const response = await fetch(`${API_BASES.activepay}/v1/transactions`, {
        method: 'POST',
        headers: { 'Authorization': auth, 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(body)
    });
    if (!response.ok) {
        let errData = {};
        try { errData = await response.json(); } catch (e) { }
        console.error('ActivePay Error Detail:', errData);
        throw new Error(errData.message ? `${errData.message} | Detalhes: ${JSON.stringify(errData)}` : `Erro ActivePay: ${response.status}`);
    }
    const data = await response.json();
    console.log('ActivePay response:', data);
    let pixCopyPaste = null;
    let qrCodeUrl = null;
    if (data.data && data.data.pix && data.data.pix.qrcode) {
        pixCopyPaste = data.data.pix.qrcode;
    } else if (data.pix && data.pix.qrcode) {
        pixCopyPaste = data.pix.qrcode;
    } else if (data.qrcode) {
        pixCopyPaste = data.qrcode;
    }
    return { pixCopyPaste, qrCodeUrl, raw: data };
}

// ===== GATEWAY: UNIPAY/FASTSOFT (idêntico ao checkout) =====
async function createPixUniPay(config, customerData, amountCents, productName) {
    const creds = config.gateways.unipay;
    const auth = 'Basic ' + btoa_utf8('x:' + creds.secret_key);
    const body = {
        amount: amountCents,
        paymentMethod: "PIX",
        customer: {
            name: customerData.name,
            email: customerData.email,
            phone: customerData.phone.replace(/\D/g, ''),
            document: {
                number: customerData.cpf.replace(/\D/g, ''),
                type: "CPF"
            }
        },
        items: [{
            title: productName,
            unitPrice: amountCents,
            quantity: 1,
            tangible: false,
            externalRef: "checkout-pix"
        }],
        pix: {
            expiresInDays: 1
        },
        traceable: true
    };
    console.log('UNIPAY UPSELL PAYLOAD:', JSON.stringify(body, null, 2));
    const response = await fetch(`${API_BASES.unipay}/api/user/transactions`, {
        method: 'POST',
        headers: { 'Authorization': auth, 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(body)
    });
    if (!response.ok) {
        let errData = {};
        try { errData = await response.json(); } catch (e) { }
        console.error('FATAL UNIPAY API ERROR RESPONSE:', JSON.stringify(errData, null, 2));
        throw new Error(errData.message ? `${errData.message} | Detalhes: ${JSON.stringify(errData)}` : `Erro UniPay: ${response.status}`);
    }
    const data = await response.json();
    console.log('UniPay response:', data);
    let pixCopyPaste = null;
    let qrCodeUrl = null;
    if (data.data && data.data.pix && data.data.pix.qrcode) {
        pixCopyPaste = data.data.pix.qrcode;
    } else if (data.pix && data.pix.qrcode) {
        pixCopyPaste = data.pix.qrcode;
    } else if (data.qrcode) {
        pixCopyPaste = data.qrcode;
    }
    return { pixCopyPaste, qrCodeUrl, raw: data };
}

// ===== GATEWAY: PAGUEX =====
async function createPixPagueX(config, customerData, amountCents, productName) {
    const creds = config.gateways.paguex;
    const auth = 'Basic ' + btoa_utf8(creds.public_key + ':' + creds.secret_key);
    const body = {
        amount: amountCents, payment_method: "pix",
        postback_url: "https://webhook.site/paguex-postback",
        customer: { name: customerData.name, email: customerData.email, phone: customerData.phone, document: { number: customerData.cpf, type: "cpf" } },
        items: [{ title: productName, unit_price: amountCents, quantity: 1, tangible: false, external_ref: "upsell-pix" }],
        pix: { expires_in_days: 1 },
        metadata: { provider_name: "upsell" }
    };
    const response = await fetch(`${API_BASES.paguex}/v1/payment-transaction/create`, {
        method: 'POST', headers: { 'Authorization': auth, 'Content-Type': 'application/json', 'Accept': 'application/json' }, body: JSON.stringify(body)
    });
    if (!response.ok) { let e = {}; try { e = await response.json(); } catch (_) { } throw new Error(e.message || `Erro PagueX: ${response.status}`); }
    const data = await response.json();
    console.log('PagueX response:', data);
    let pixCopyPaste = null, qrCodeUrl = null;
    if (data?.data?.pix?.qr_code) { pixCopyPaste = data.data.pix.qr_code; qrCodeUrl = data.data.pix.url || null; }
    else if (data?.pix?.qr_code) { pixCopyPaste = data.pix.qr_code; }
    return { pixCopyPaste, qrCodeUrl, raw: data };
}

// ===== GATEWAY: MOONFY =====
async function createPixMoonfy(config, customerData, amountCents, productName) {
    const creds = config.gateways.moonfy;
    const auth = 'Basic ' + btoa_utf8(creds.public_key + ':' + creds.secret_key);
    const body = {
        amount: amountCents,
        paymentMethod: "pix",
        customer: {
            name: customerData.name,
            email: customerData.email,
            phone: customerData.phone,
            document: { number: customerData.cpf, type: "cpf" }
        },
        items: [{ title: productName, unitPrice: amountCents, quantity: 1, tangible: false, externalRef: "upsell-pix" }],
        pix: { expiresInDays: 1 }
    };
    const response = await fetch(`${API_BASES.moonfy}/v1/transactions`, {
        method: 'POST',
        headers: { 'Authorization': auth, 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(body)
    });
    if (!response.ok) {
        let errData = {}; try { errData = await response.json(); } catch (e) { }
        throw new Error(errData.message || `Erro Moonfy: ${response.status}`);
    }
    const data = await response.json();
    console.log('Moonfy response:', data);
    let pixCopyPaste = null, qrCodeUrl = null;
    if (data.data?.pix?.qrcode) pixCopyPaste = data.data.pix.qrcode;
    else if (data.pix?.qrcode) pixCopyPaste = data.pix.qrcode;
    else if (data.qrcode) pixCopyPaste = data.qrcode;
    return { pixCopyPaste, qrCodeUrl, raw: data };
}

// ===== GATEWAY: MANGOFY =====
async function createPixMangofy(config, customerData, amountCents, productName) {
    const creds = config.gateways.mangofy;
    let clientIp = '0.0.0.0';
    try { const r = await fetch('https://api.ipify.org?format=json'); const d = await r.json(); clientIp = d.ip || '0.0.0.0'; } catch (e) { }
    const body = {
        store_code: creds.store_code,
        payment_method: "pix",
        payment_format: "upsell",
        installments: 1,
        payment_amount: amountCents,
        items: [{ title: productName, unit_price: amountCents, quantity: 1, tangible: false, external_ref: "upsell-pix" }],
        customer: { name: customerData.name, email: customerData.email, phone: customerData.phone, document: customerData.cpf, ip: clientIp },
        pix: { expires_in_days: 1 },
        postback_url: "https://webhook.site/mangofy-postback",
        external_code: "upsell-" + Date.now()
    };
    const response = await fetch(`${API_BASES.mangofy}/api/v1/payment`, {
        method: 'POST',
        headers: {
            'Authorization': creds.api_key, 'Store-Code': creds.store_code,
            'Content-Type': 'application/json', 'Accept': 'application/json'
        },
        body: JSON.stringify(body)
    });
    if (!response.ok) { let e = {}; try { e = await response.json(); } catch (_) { } throw new Error(e.message || e.data?.message || `Erro Mangofy: ${response.status}`); }
    const resp_json = await response.json();
    const data = resp_json.data || resp_json;
    console.log('Mangofy response:', resp_json);
    let pixCopyPaste = null, qrCodeUrl = null;
    if (data.pix?.pix_qrcode_text) pixCopyPaste = data.pix.pix_qrcode_text;
    else if (data.pix?.qrcode_text) pixCopyPaste = data.pix.qrcode_text;
    else if (data.pix_qrcode) pixCopyPaste = data.pix_qrcode;
    else if (data.pix?.qrcode) pixCopyPaste = data.pix.qrcode;
    else if (data.qrcode) pixCopyPaste = data.qrcode;
    else if (data.qr_code) pixCopyPaste = data.qr_code;
    else if (data.pix?.qr_code) pixCopyPaste = data.pix.qr_code;
    return { pixCopyPaste, qrCodeUrl, raw: resp_json };
}

// ===== GATEWAY: OTIMIZE PAGAMENTOS =====
async function createPixOtimize(config, customerData, amountCents, productName) {
    const creds = config.gateways.otimize;
    const auth = 'Basic ' + btoa_utf8(creds.secret_key + ':x');
    const body = {
        amount: amountCents, paymentMethod: "pix",
        customer: { name: customerData.name, email: customerData.email, phone: customerData.phone, document: { number: customerData.cpf, type: "cpf" } },
        items: [{ title: productName, unitPrice: amountCents, quantity: 1, tangible: false, externalRef: "upsell-pix" }],
        pix: { expiresInDays: 1 }
    };
    const response = await fetch(`${API_BASES.otimize}/v1/transactions`, {
        method: 'POST', headers: { 'Authorization': auth, 'Content-Type': 'application/json', 'Accept': 'application/json' }, body: JSON.stringify(body)
    });
    if (!response.ok) { let e = {}; try { e = await response.json(); } catch (_) { } throw new Error(e.message || `Erro Otimize: ${response.status}`); }
    const data = await response.json();
    console.log('Otimize response:', data);
    let pixCopyPaste = data?.data?.pix?.qrcode || data?.pix?.qrcode || data?.data?.pix?.qr_code || data?.qrcode || null;
    return { pixCopyPaste, qrCodeUrl: null, raw: data };
}

// ===== EXTRACT PIX CODE =====
function extractPixCode(data) {
    return data?.pixCopyPaste || data?.pix?.pix_qr_code || data?.data?.pix?.qrcode || data?.pix?.qrcode || data?.pix?.qr_code || data?.qrcode || data?.data?.qrcode || null;
}

function extractTransactionId(data, gateway) {
    if (data?.raw) {
        const raw = data.raw;
        if (gateway === 'ironpay') return raw?.hash || raw?.data?.hash || raw?.id || raw?.data?.id;
        if (gateway === 'activepay') return raw?.data?.id || raw?.id || raw?.data?.secureId;
        if (gateway === 'unipay') return raw?.data?.id || raw?.id;
        if (gateway === 'paguex') return raw?.data?.id || raw?.Id || raw?.id;
        if (gateway === 'moonfy') return raw?.data?.id || raw?.id;
        if (gateway === 'mangofy') return raw?.payment_code || raw?.id;
        if (gateway === 'otimize') return raw?.data?.id || raw?.id;
    }
    if (gateway === 'ironpay') return data?.hash || data?.data?.hash || data?.id || data?.data?.id;
    if (gateway === 'activepay') return data?.data?.id || data?.id || data?.data?.secureId;
    if (gateway === 'unipay') return data?.data?.id || data?.id;
    if (gateway === 'paguex') return data?.data?.id || data?.Id || data?.id;
    if (gateway === 'moonfy') return data?.data?.id || data?.id;
    if (gateway === 'mangofy') return data?.payment_code || data?.id;
    if (gateway === 'otimize') return data?.data?.id || data?.id;
    return null;
}

// ===== GENERATE PIX =====
async function generateUpsellPix() {
    const config = getGatewayConfig();
    if (!config || !config.activeGateway) {
        showError('Nenhum gateway configurado no painel.');
        return;
    }

    const btn = document.getElementById('btn-pay');
    const btnText = document.getElementById('btn-pay-text');
    btn.disabled = true;
    btnText.innerHTML = '<span class="spinner"></span>Gerando Pix...';

    const customer = getCustomerData();
    const amountStr = config.upsell?.amount || '78,25';
    const amountCents = amountToCents(amountStr);

    try {
        let result;
        switch (config.activeGateway) {
            case 'ironpay': result = await createPixIronPay(config, customer, amountCents, "Produto 2"); break;
            case 'activepay': result = await createPixActivePay(config, customer, amountCents, "Produto 2"); break;
            case 'unipay': result = await createPixUniPay(config, customer, amountCents, "Produto 2"); break;
            case 'paguex': result = await createPixPagueX(config, customer, amountCents, "Produto 2"); break;
            case 'moonfy': result = await createPixMoonfy(config, customer, amountCents, "Produto 2"); break;
            case 'mangofy': result = await createPixMangofy(config, customer, amountCents, "Produto 2"); break;
            case 'otimize': result = await createPixOtimize(config, customer, amountCents, "Produto 2"); break;
            default: throw new Error('Gateway desconhecido');
        }

        console.log('Upsell PIX result:', result);

        const pixCode = extractPixCode(result);
        currentTxId = extractTransactionId(result, config.activeGateway);

        if (!pixCode) {
            showError('Não foi possível gerar o código PIX. Verifique as credenciais.');
            btn.disabled = false;
            btnText.textContent = 'Pagar Taxa Agora';
            return;
        }

        // Show PIX
        btn.style.display = 'none';
        document.getElementById('pix-section').classList.add('show');
        document.getElementById('pix-code').textContent = pixCode;

        // Render QR
        const qrWrap = document.getElementById('qr-wrap');
        qrWrap.innerHTML = '<div id="qr-render" style="width:192px;height:192px;"></div>';
        try {
            new QRCode(document.getElementById('qr-render'), {
                text: pixCode, width: 192, height: 192,
                colorDark: "#000", colorLight: "#fff",
                correctLevel: QRCode.CorrectLevel.M
            });
        } catch (e) {
            qrWrap.innerHTML = `<img src="https://api.qrserver.com/v1/create-qr-code/?size=192x192&data=${encodeURIComponent(pixCode)}" style="width:192px;height:192px;border-radius:8px;" />`;
        }

        // Start polling
        if (currentTxId) {
            document.getElementById('checking-payment').classList.add('show');
            startPolling(config);
        }

    } catch (err) {
        console.error('Upsell PIX error:', err);
        showError('Erro: ' + err.message);
        btn.disabled = false;
        btnText.textContent = 'Pagar Taxa Agora';
    }
}

// ===== COPY PIX =====
function copyPixCode() {
    const text = document.getElementById('pix-code').textContent;
    navigator.clipboard.writeText(text);
    const btn = document.getElementById('btn-copy');
    btn.textContent = '✓ Copiado!';
    btn.style.background = '#22c55e';
    setTimeout(() => { btn.textContent = 'Copiar código Pix'; btn.style.background = '#e10075'; }, 2500);
}

// ===== POLLING =====
async function checkPaymentStatus(config) {
    if (!currentTxId) return false;

    try {
        let res, data;
        switch (config.activeGateway) {
            case 'ironpay': {
                const creds = config.gateways.ironpay;
                res = await fetch(`${API_BASES.ironpay}/api/public/v1/transactions?api_token=${encodeURIComponent(creds.token)}&hash=${currentTxId}`, { headers: { 'Accept': 'application/json' } });
                break;
            }
            case 'activepay': {
                const creds = config.gateways.activepay;
                const auth = 'Basic ' + btoa_utf8(creds.public_key + ':' + creds.secret_key);
                res = await fetch(`${API_BASES.activepay}/v1/transactions/${currentTxId}`, { headers: { 'Authorization': auth, 'Accept': 'application/json' } });
                break;
            }
            case 'unipay': {
                const creds = config.gateways.unipay;
                const auth = 'Basic ' + btoa_utf8('x:' + creds.secret_key);
                res = await fetch(`${API_BASES.unipay}/api/user/transactions/${currentTxId}`, { headers: { 'Authorization': auth, 'Accept': 'application/json' } });
                break;
            }
            case 'paguex': {
                const creds = config.gateways.paguex;
                const auth = 'Basic ' + btoa_utf8(creds.public_key + ':' + creds.secret_key);
                res = await fetch(`${API_BASES.paguex}/v1/payment-transaction/info/${currentTxId}`, { headers: { 'Authorization': auth, 'Accept': 'application/json' } });
                break;
            }
            case 'moonfy': {
                const creds = config.gateways.moonfy;
                const auth = 'Basic ' + btoa_utf8(creds.public_key + ':' + creds.secret_key);
                res = await fetch(`${API_BASES.moonfy}/v1/transactions/${currentTxId}`, { headers: { 'Authorization': auth, 'Accept': 'application/json' } });
                break;
            }
            case 'mangofy': {
                const creds = config.gateways.mangofy;
                res = await fetch(`${API_BASES.mangofy}/api/v1/payment/${currentTxId}`, { 
                    headers: { 'Authorization': creds.api_key, 'Store-Code': creds.store_code, 'Accept': 'application/json' } 
                });
                break;
            }
            case 'otimize': {
                const creds = config.gateways.otimize;
                const auth = 'Basic ' + btoa_utf8(creds.secret_key + ':x');
                res = await fetch(`${API_BASES.otimize}/v1/transactions/${currentTxId}`, { headers: { 'Authorization': auth, 'Accept': 'application/json' } });
                break;
            }
        }

        if (!res || !res.ok) return false;
        data = await res.json();
        console.log('Poll status:', data);
        console.log('[Poll] Gateway:', config.activeGateway, '| Full response:', JSON.stringify(data));

        let s = '';
        if (config.activeGateway === 'ironpay') {
            const txList = Array.isArray(data?.data) ? data.data : [];
            const tx = txList.find(t => t.hash === currentTxId);
            s = String(tx?.payment_status || '').toLowerCase();
            console.log('[Poll] IronPay tx found:', !!tx, '| payment_status:', s);
        } else if (config.activeGateway === 'unipay') {
            s = String(data?.data?.status || '').toLowerCase();
            console.log('[Poll] UniPay payment status:', s);
        } else if (config.activeGateway === 'mangofy') {
            s = String(data?.payment_status || data?.data?.payment_status || data?.status || '').toLowerCase();
            console.log('[Poll] Mangofy payment status:', s);
        } else if (config.activeGateway === 'otimize') {
            s = String(data?.data?.status || data?.status || '').toLowerCase();
        } else {
            const status = data?.status || data?.data?.status || data?.Status || '';
            s = String(status).toLowerCase();
        }
        console.log('[Poll] Status detected:', s);
        return ['paid', 'approved', 'complete', 'completed'].includes(s);
    } catch (e) {
        console.log('Polling error:', e);
        return false;
    }
}

function startPolling(config) {
    if (pollingInterval) clearInterval(pollingInterval);
    pollingInterval = setInterval(async () => {
        const paid = await checkPaymentStatus(config);
        if (paid) {
            clearInterval(pollingInterval);
            document.getElementById('checking-payment').innerHTML = '✅ <strong>Pagamento confirmado!</strong>';
            setTimeout(() => {
                window.location.href = '../iof/';
            }, 1500);
        }
    }, 5000);
}

function showError(msg) {
    const el = document.getElementById('error-msg');
    el.textContent = msg;
    el.style.display = 'block';
}
