// ===== CHECKOUT - MULTI-GATEWAY PIX =====
// Lê a config do localStorage (salva pelo painel) e gera PIX no gateway ativo

const STORAGE_KEY = 'gateway_config';

// Names for Notification
const NAMES = [
    "Maria Silva", "João Santos", "Ana Oliveira", "Pedro Souza", "Juliana Costa",
    "Carlos Pereira", "Fernanda Lima", "Lucas Almeida", "Patrícia Ferreira", "Rafael Rodrigues",
    "Camila Nascimento", "Bruno Araújo", "Letícia Martins", "Diego Barbosa", "Amanda Ribeiro",
    "Thiago Carvalho", "Larissa Gomes", "Felipe Cardoso", "Gabriela Rocha", "Matheus Correia",
    "Bianca Dias", "Gustavo Monteiro", "Isabela Teixeira", "Leonardo Moreira", "Natália Vieira",
    "Eduardo Nunes", "Mariana Mendes", "Vinícius Pinto", "Carolina Batista", "André Cavalcanti"
];

// ===== FORMATAÇÃO & VALIDAÇÃO =====
const formatCPF = (value) => {
    return value.replace(/\D/g, "").slice(0, 11)
        .replace(/(\d{3})(\d)/, "$1.$2")
        .replace(/(\d{3})(\d)/, "$1.$2")
        .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
};

const formatPhone = (value) => {
    return value.replace(/\D/g, "").slice(0, 11)
        .replace(/(\d{2})(\d)/, "($1) $2")
        .replace(/(\d{5})(\d)/, "$1-$2");
};

const validateEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim());
const validatePhone = (v) => v.replace(/\D/g, "").length === 11;
const validateName = (v) => v.trim().split(/\s+/).length >= 2;
const validateCPF = (v) => v.replace(/\D/g, "").length === 11;

const validateField = (field, value) => {
    switch (field) {
        case "email": return !value.trim() ? "E-mail obrigatório" : !validateEmail(value) ? "E-mail inválido" : null;
        case "phone": return !value.trim() ? "Telefone obrigatório" : !validatePhone(value) ? "Telefone inválido" : null;
        case "name": return !value.trim() ? "Nome obrigatório" : !validateName(value) ? "Informe nome e sobrenome" : null;
        case "cpf": return !value.trim() ? "CPF obrigatório" : !validateCPF(value) ? "CPF inválido" : null;
    }
    return null;
};

// ===== ELEMENTOS UI =====
const inputs = {
    email: document.getElementById('email'),
    phone: document.getElementById('phone'),
    name: document.getElementById('name'),
    cpf: document.getElementById('cpf'),
};

const errors = {
    email: document.getElementById('err-email'),
    phone: document.getElementById('err-phone'),
    name: document.getElementById('err-name'),
    cpf: document.getElementById('err-cpf'),
};

const btnGeneratePix = document.getElementById('btn-generate-pix');
const btnText = document.getElementById('btn-text');
const btnLoader = document.getElementById('btn-loader');
const prePixSection = document.getElementById('pre-pix-section');
const postPixSection = document.getElementById('post-pix-section');
const qrImage = document.getElementById('qr-image');
const pixCode = document.getElementById('pix-code');
const btnCopyPix = document.getElementById('btn-copy-pix');
const apiErrorEl = document.getElementById('api-error');

// ===== INIT VALUES FROM PANEL =====
(function init() {
    try {
        if (typeof GLOBAL_CONFIG !== 'undefined') {
            const config = GLOBAL_CONFIG;
            const amount = config?.product?.amount || '98,52';
            const subtotal = document.getElementById('cart-subtotal');
            const total = document.getElementById('cart-total');

            if (subtotal) subtotal.textContent = 'R$ ' + amount;
            if (total) total.textContent = 'R$ ' + amount;
        }
    } catch (e) {
        console.error('Erro ao ler config do painel:', e);
    }
})();

// Máscaras
inputs.phone.addEventListener('input', (e) => { e.target.value = formatPhone(e.target.value); });
inputs.cpf.addEventListener('input', (e) => { e.target.value = formatCPF(e.target.value); });

// Validação no blur
Object.keys(inputs).forEach(field => {
    inputs[field].addEventListener('blur', () => {
        const errStr = validateField(field, inputs[field].value);
        if (errStr) {
            errors[field].textContent = errStr;
            errors[field].classList.remove('hidden');
            inputs[field].classList.add('border-destructive', 'focus:ring-destructive/40');
            inputs[field].classList.remove('border-input', 'focus:ring-ring');
        } else {
            errors[field].classList.add('hidden');
            inputs[field].classList.remove('border-destructive', 'focus:ring-destructive/40');
            inputs[field].classList.add('border-input', 'focus:ring-ring');
        }
    });
});

// ===== LER CONFIG DO PAINEL =====
function getGatewayConfig() {
    if (typeof GLOBAL_CONFIG !== 'undefined') {
        return GLOBAL_CONFIG;
    }
    return null;
}

// ===== HELPERS =====
function amountToCents(amountStr) {
    // "98,52" -> 9852
    const clean = amountStr.replace(/[^\d,\.]/g, '').replace(',', '.');
    return Math.round(parseFloat(clean) * 100);
}

function btoa_utf8(str) {
    return btoa(unescape(encodeURIComponent(str)));
}

function extractTransactionId(data, gateway) {
    if (gateway === 'ironpay') return data?.hash || data?.data?.hash || data?.id || data?.data?.id;
    if (gateway === 'activepay') return data?.data?.id || data?.id || data?.data?.secureId;
    if (gateway === 'unipay') return data?.data?.id || data?.id;
    if (gateway === 'paguex') return data?.data?.id || data?.Id || data?.id;
    if (gateway === 'moonfy') return data?.data?.id || data?.id;
    if (gateway === 'mangofy') return data?.payment_code || data?.id;
    if (gateway === 'otimize') return data?.data?.id || data?.id;
    if (gateway === 'sigilopay') return data?.transactionId || data?.id;
    return null;
}

let currentTxId = null;
let pollingInterval = null;

// ===== GATEWAY: IRONPAY =====
async function generatePixIronPay(config, customerData, amountCents, productName) {
    const creds = config.gateways.ironpay;

    // offer_hash e product_hash são OBRIGATÓRIOS no IronPay
    if (!creds.offer_hash || !creds.product_hash) {
        throw new Error('IronPay requer Offer Hash e Product Hash. Preencha no painel.');
    }

    const url = `${API_BASES.ironpay}/api/public/v1/transactions?api_token=${encodeURIComponent(creds.token)}`;

    const body = {
        amount: amountCents,
        offer_hash: creds.offer_hash,
        payment_method: "pix",
        customer: {
            name: customerData.name,
            email: customerData.email,
            phone_number: customerData.phone,
            document: customerData.cpf,
            street_name: "Rua Principal",
            number: "1",
            complement: "",
            neighborhood: "Centro",
            city: "São Paulo",
            state: "SP",
            zip_code: "01001000"
        },
        cart: [{
            product_hash: creds.product_hash,
            title: productName,
            cover: null,
            price: amountCents,
            quantity: 1,
            operation_type: 1,
            tangible: false
        }],
        expire_in_days: 1,
        transaction_origin: "api"
    };

    const response = await fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(body)
    });

    if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.message || `Erro IronPay: ${response.status}`);
    }

    const data = await response.json();
    console.log('IronPay response:', data);

    // IronPay: pix.pix_qr_code = copia-e-cola, pix.pix_url = URL do QR
    let pixCopyPaste = data?.pix?.pix_qr_code || data?.pix?.qrcode || data?.pix?.qr_code || data?.qrcode || null;
    let qrCodeUrl = data?.pix?.pix_url || data?.pix?.qr_code_url || null;

    return { pixCopyPaste, qrCodeUrl, raw: data };
}

// ===== GATEWAY: ACTIVEPAY =====
async function generatePixActivePay(config, customerData, amountCents, productName) {
    const creds = config.gateways.activepay;
    const auth = 'Basic ' + btoa_utf8(creds.public_key + ':' + creds.secret_key);

    const body = {
        amount: amountCents,
        paymentMethod: "pix",
        customer: {
            name: customerData.name,
            email: customerData.email,
            phone: customerData.phone,
            document: {
                number: customerData.cpf,
                type: "cpf"
            }
        },
        items: [{
            title: productName,
            unitPrice: amountCents,
            quantity: 1,
            tangible: false,
            externalRef: "checkout-pix"
        }],
        pix: {
            expiresInDays: 1
        }
    };

    const response = await fetch(`${API_BASES.activepay}/v1/transactions`, {
        method: 'POST',
        headers: {
            'Authorization': auth,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(body)
    });

    if (!response.ok) {
        let errData = {};
        try { errData = await response.json(); } catch (e) { }
        console.error('ActivePay Error Detail:', errData);
        throw new Error(errData.message ? `${errData.message} | Detalhes: ${JSON.stringify(errData)}` : `Erro ActivePay: ${response.status}`);
    }

    const data = await response.json();
    console.log('ActivePay response:', data);

    // ActivePay: data.pix.qrcode contém o código copia-e-cola
    let pixCopyPaste = null;
    let qrCodeUrl = null;

    if (data.data && data.data.pix && data.data.pix.qrcode) {
        pixCopyPaste = data.data.pix.qrcode;
    } else if (data.pix && data.pix.qrcode) {
        pixCopyPaste = data.pix.qrcode;
    } else if (data.qrcode) {
        pixCopyPaste = data.qrcode;
    }

    return { pixCopyPaste, qrCodeUrl, raw: data };
}

// ===== GATEWAY: UNIPAY (FASTSOFT) =====
async function generatePixUniPay(config, customerData, amountCents, productName) {
    const creds = config.gateways.unipay;
    // UniPay/FastSoft: auth é x:SECRET_KEY (literal "x" como prefixo)
    const auth = 'Basic ' + btoa_utf8('x:' + creds.secret_key);

    const body = {
        amount: amountCents,
        paymentMethod: "PIX",
        customer: {
            name: customerData.name,
            email: customerData.email,
            phone: customerData.phone.replace(/\D/g, ''),
            document: {
                number: customerData.cpf.replace(/\D/g, ''),
                type: "CPF"
            }
        },
        items: [{
            title: productName,
            unitPrice: amountCents,
            quantity: 1,
            tangible: false,
            externalRef: "checkout-pix"
        }],
        pix: {
            expiresInDays: 1
        },
        traceable: true
    };

    const response = await fetch(`${API_BASES.unipay}/api/user/transactions`, {
        method: 'POST',
        headers: {
            'Authorization': auth,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(body)
    });

    if (!response.ok) {
        let errData = {};
        try { errData = await response.json(); } catch (e) { }
        console.error("FATAL UNIPAY API ERROR RESPONSE:", JSON.stringify(errData, null, 2));
        throw new Error(errData.message ? `${errData.message} | Detalhes: ${JSON.stringify(errData)}` : `Erro UniPay: ${response.status}`);
    }

    const data = await response.json();
    console.log('UniPay response:', data);

    // UniPay: buscar PIX code na resposta
    let pixCopyPaste = null;
    let qrCodeUrl = null;

    if (data.data && data.data.pix && data.data.pix.qrcode) {
        pixCopyPaste = data.data.pix.qrcode;
    } else if (data.pix && data.pix.qrcode) {
        pixCopyPaste = data.pix.qrcode;
    } else if (data.qrcode) {
        pixCopyPaste = data.qrcode;
    }

    return { pixCopyPaste, qrCodeUrl, raw: data };
}

// ===== GATEWAY: PAGUEX =====
async function generatePixPagueX(config, customerData, amountCents, productName) {
    const creds = config.gateways.paguex;
    const auth = 'Basic ' + btoa_utf8(creds.public_key + ':' + creds.secret_key);

    const body = {
        amount: amountCents,
        payment_method: "pix",
        postback_url: "https://webhook.site/paguex-postback",
        customer: {
            name: customerData.name,
            email: customerData.email,
            phone: customerData.phone,
            document: {
                number: customerData.cpf,
                type: "cpf"
            }
        },
        items: [{
            title: productName,
            unit_price: amountCents,
            quantity: 1,
            tangible: false,
            external_ref: "checkout-pix"
        }],
        pix: {
            expires_in_days: 1
        },
        metadata: {
            provider_name: "checkout"
        }
    };

    const response = await fetch(`${API_BASES.paguex}/v1/payment-transaction/create`, {
        method: 'POST',
        headers: {
            'Authorization': auth,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(body)
    });

    if (!response.ok) {
        let errData = {};
        try { errData = await response.json(); } catch (e) { }
        console.error('PagueX Error Detail:', errData);
        throw new Error(errData.message || `Erro PagueX: ${response.status}`);
    }

    const data = await response.json();
    console.log('PagueX response:', data);

    // PagueX response: data.data.pix.qr_code (data e pix são objetos, não arrays)
    let pixCopyPaste = null;
    let qrCodeUrl = null;
    if (data?.data?.pix?.qr_code) {
        pixCopyPaste = data.data.pix.qr_code;
        qrCodeUrl = data.data.pix.url || null;
    } else if (data?.pix?.qr_code) {
        pixCopyPaste = data.pix.qr_code;
    }

    return { pixCopyPaste, qrCodeUrl, raw: data };
}

// ===== GATEWAY: MOONFY =====
async function generatePixMoonfy(config, customerData, amountCents, productName) {
    const creds = config.gateways.moonfy;
    const auth = 'Basic ' + btoa_utf8(creds.public_key + ':' + creds.secret_key);

    const body = {
        amount: amountCents,
        paymentMethod: "pix",
        customer: {
            name: customerData.name,
            email: customerData.email,
            phone: customerData.phone,
            document: {
                number: customerData.cpf,
                type: "cpf"
            }
        },
        items: [{
            title: productName,
            unitPrice: amountCents,
            quantity: 1,
            tangible: false,
            externalRef: "checkout-pix"
        }],
        pix: {
            expiresInDays: 1
        }
    };

    const response = await fetch(`${API_BASES.moonfy}/v1/transactions`, {
        method: 'POST',
        headers: {
            'Authorization': auth,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(body)
    });

    if (!response.ok) {
        let errData = {};
        try { errData = await response.json(); } catch (e) { }
        console.error('Moonfy Error Detail:', errData);
        throw new Error(errData.message || `Erro Moonfy: ${response.status}`);
    }

    const data = await response.json();
    console.log('Moonfy response:', data);

    // Moonfy: data.pix.qrcode (igual ao activepay)
    let pixCopyPaste = null;
    let qrCodeUrl = null;

    if (data.data && data.data.pix && data.data.pix.qrcode) {
        pixCopyPaste = data.data.pix.qrcode;
    } else if (data.pix && data.pix.qrcode) {
        pixCopyPaste = data.pix.qrcode;
    } else if (data.qrcode) {
        pixCopyPaste = data.qrcode;
    }

    return { pixCopyPaste, qrCodeUrl, raw: data };
}

// ===== GATEWAY: MANGOFY =====
async function generatePixMangofy(config, customerData, amountCents, productName) {
    const creds = config.gateways.mangofy;

    // Busca o IP do cliente
    let clientIp = '0.0.0.0';
    try {
        const ipRes = await fetch('https://api.ipify.org?format=json');
        const ipData = await ipRes.json();
        clientIp = ipData.ip || '0.0.0.0';
    } catch (e) { clientIp = '0.0.0.0'; }

    const body = {
        store_code: creds.store_code,
        payment_method: "pix",
        payment_format: "regular",
        installments: 1,
        payment_amount: amountCents,
        items: [{
            title: productName,
            unit_price: amountCents,
            quantity: 1,
            tangible: false,
            external_ref: "checkout-pix"
        }],
        customer: {
            name: customerData.name,
            email: customerData.email,
            phone: customerData.phone,
            document: customerData.cpf,
            ip: clientIp
        },
        pix: {
            expires_in_days: 1
        },
        postback_url: "https://webhook.site/mangofy-postback",
        external_code: "checkout-" + Date.now()
    };

    const response = await fetch(`${API_BASES.mangofy}/api/v1/payment`, {
        method: 'POST',
        headers: {
            'Authorization': creds.api_key,
            'Store-Code': creds.store_code,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(body)
    });

    if (!response.ok) {
        let errData = {};
        try { errData = await response.json(); } catch (e) { }
        console.error('Mangofy Error Detail:', errData);
        throw new Error(errData.message || `Erro Mangofy: ${response.status}`);
    }

    const response_json = await response.json();
    // Mangofy wraps the payload inside a 'data' key
    const data = response_json.data || response_json;
    console.log('Mangofy response:', response_json);

    let pixCopyPaste = null;
    let qrCodeUrl = null;

    // Mangofy retorna: { data: { pix: { pix_qrcode_text: '...' } } }
    if (data.pix?.pix_qrcode_text) {
        pixCopyPaste = data.pix.pix_qrcode_text;
    } else if (data.pix?.qrcode_text) {
        pixCopyPaste = data.pix.qrcode_text;
    } else if (data.pix_qrcode) {
        pixCopyPaste = data.pix_qrcode;
    } else if (data.pix?.qrcode) {
        pixCopyPaste = data.pix.qrcode;
    } else if (data.qrcode) {
        pixCopyPaste = data.qrcode;
    } else if (data.qr_code) {
        pixCopyPaste = data.qr_code;
    } else if (data.pix?.qr_code) {
        pixCopyPaste = data.pix.qr_code;
    }

    if (data.pix_qr_url) qrCodeUrl = data.pix_qr_url;
    else if (data.pix?.qr_url) qrCodeUrl = data.pix.qr_url;

    return { pixCopyPaste, qrCodeUrl, raw: response_json };
}

// ===== GATEWAY: OTIMIZE PAGAMENTOS =====
async function generatePixOtimize(config, customerData, amountCents, productName) {
    const creds = config.gateways.otimize;
    const auth = 'Basic ' + btoa_utf8(creds.secret_key + ':x');

    const body = {
        amount: amountCents,
        paymentMethod: "pix",
        customer: {
            name: customerData.name,
            email: customerData.email,
            phone: customerData.phone,
            document: {
                number: customerData.cpf,
                type: "cpf"
            }
        },
        items: [{
            title: productName,
            unitPrice: amountCents,
            quantity: 1,
            tangible: false,
            externalRef: "checkout-pix"
        }],
        pix: {
            expiresInDays: 1
        }
    };

    const response = await fetch(`${API_BASES.otimize}/v1/transactions`, {
        method: 'POST',
        headers: {
            'Authorization': auth,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(body)
    });

    if (!response.ok) {
        let errData = {};
        try { errData = await response.json(); } catch (e) { }
        console.error('Otimize Error Detail:', errData);
        throw new Error(errData.message ? `${errData.message} | Detalhes: ${JSON.stringify(errData)}` : `Erro Otimize: ${response.status}`);
    }

    const data = await response.json();
    console.log('Otimize response:', data);

    let pixCopyPaste = null;
    let qrCodeUrl = null;

    if (data.data && data.data.pix && data.data.pix.qrcode) {
        pixCopyPaste = data.data.pix.qrcode;
    } else if (data.pix && data.pix.qrcode) {
        pixCopyPaste = data.pix.qrcode;
    } else if (data.data && data.data.pix && data.data.pix.qr_code) {
        pixCopyPaste = data.data.pix.qr_code;
    } else if (data.qrcode) {
        pixCopyPaste = data.qrcode;
    }

    return { pixCopyPaste, qrCodeUrl, raw: data };
}

// ===== GATEWAY: SIGILOPAY =====
async function generatePixSigiloPay(config, customerData, amountCents, productName) {
    const creds = config.gateways.sigilopay;

    const body = {
        identifier: "checkout-" + Date.now(),
        amount: amountCents / 100, // SigiloPay usa reais em vez de centavos
        client: {
            name: customerData.name,
            email: customerData.email,
            phone: customerData.phone,
            document: customerData.cpf
        },
        products: [{
            id: "prod-1",
            name: productName,
            quantity: 1,
            price: amountCents / 100
        }],
        callbackUrl: window.location.origin + "/api/webhook/sigilopay"
    };

    const response = await fetch(`${API_BASES.sigilopay}/gateway/pix/receive`, {
        method: 'POST',
        headers: {
            'x-public-key': creds.public_key,
            'x-secret-key': creds.secret_key,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(body)
    });

    if (!response.ok) {
        let errData = {};
        try { errData = await response.json(); } catch (e) { }
        console.error('SigiloPay Error Detail:', errData);
        throw new Error(errData.message ? `${errData.message} | Detalhes: ${JSON.stringify(errData)}` : `Erro SigiloPay: ${response.status}`);
    }

    const data = await response.json();
    console.log('SigiloPay response:', data);

    let pixCopyPaste = data.pix?.code || null;
    let qrCodeUrl = data.pix?.image || null;

    return { pixCopyPaste, qrCodeUrl, raw: data };
}

// ===== GERAR QR CODE A PARTIR DO TEXTO =====
function renderQRCode(text) {
    const container = document.getElementById('qr-container');
    // Limpar conteúdo anterior
    container.innerHTML = '<div class="relative w-48 h-48"><div id="qr-render" style="width:192px;height:192px;"></div></div>';

    const qrRender = document.getElementById('qr-render');
    try {
        new QRCode(qrRender, {
            text: text,
            width: 192,
            height: 192,
            colorDark: "#000000",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.M
        });
    } catch (e) {
        console.error('Erro ao gerar QR Code:', e);
        // Fallback: usar API externa
        container.innerHTML = `<div class="relative w-48 h-48"><img src="https://api.qrserver.com/v1/create-qr-code/?size=192x192&data=${encodeURIComponent(text)}" alt="QR Code Pix" class="w-full h-full rounded-lg" /></div>`;
    }
}

// ===== BOTÃO GERAR PIX =====
btnGeneratePix.addEventListener('click', async () => {
    let hasError = false;

    // Validar campos
    Object.keys(inputs).forEach(field => {
        const errStr = validateField(field, inputs[field].value);
        if (errStr) {
            errors[field].textContent = errStr;
            errors[field].classList.remove('hidden');
            inputs[field].classList.add('border-destructive', 'focus:ring-destructive/40');
            inputs[field].classList.remove('border-input', 'focus:ring-ring');
            hasError = true;
        } else {
            errors[field].classList.add('hidden');
        }
    });

    if (hasError) return;

    // Verificar se tem gateway configurado
    const config = getGatewayConfig();
    if (!config || !config.activeGateway) {
        apiErrorEl.textContent = "⚠️ Nenhum gateway configurado. Acesse o painel para ativar um gateway.";
        apiErrorEl.classList.remove('hidden');
        return;
    }

    const gwCreds = config.gateways?.[config.activeGateway];
    if (!gwCreds) {
        apiErrorEl.textContent = "⚠️ Credenciais não encontradas para o gateway " + config.activeGateway;
        apiErrorEl.classList.remove('hidden');
        return;
    }

    // Loading
    btnGeneratePix.disabled = true;
    btnText.textContent = "Gerando Pix...";
    btnLoader.classList.remove('hidden');
    apiErrorEl.classList.add('hidden');

    const customerData = {
        name: inputs.name.value.trim(),
        email: inputs.email.value.trim(),
        cpf: inputs.cpf.value.replace(/\D/g, ""),
        phone: inputs.phone.value.replace(/\D/g, "")
    };

    // Salvar dados do cliente para o upsell
    localStorage.setItem('checkout_customer', JSON.stringify(customerData));

    const amountStr = config.product?.amount || '98,52';
    const amountCents = amountToCents(amountStr);
    const productName = config.product?.name || 'Feirão Serasa 2026';

    try {
        let result;

        switch (config.activeGateway) {
            case 'ironpay':
                result = await generatePixIronPay(config, customerData, amountCents, "Produto 1");
                break;
            case 'activepay':
                result = await generatePixActivePay(config, customerData, amountCents, "Produto 1");
                break;
            case 'unipay':
                result = await generatePixUniPay(config, customerData, amountCents, "Produto 1");
                break;
            case 'paguex':
                result = await generatePixPagueX(config, customerData, amountCents, "Produto 1");
                break;
            case 'moonfy':
                result = await generatePixMoonfy(config, customerData, amountCents, "Produto 1");
                break;
            case 'mangofy':
                result = await generatePixMangofy(config, customerData, amountCents, "Produto 1");
                break;
            case 'otimize':
                result = await generatePixOtimize(config, customerData, amountCents, "Produto 1");
                break;
            case 'sigilopay':
                result = await generatePixSigiloPay(config, customerData, amountCents, "Produto 1");
                break;
            default:
                throw new Error('Gateway desconhecido: ' + config.activeGateway);
        }

        console.log('Gateway result:', result);

        // Extrair transaction ID para polling
        currentTxId = extractTransactionId(result.raw, config.activeGateway);
        console.log('Transaction ID:', currentTxId);

        // Mostrar seção PIX
        prePixSection.classList.add('hidden');
        postPixSection.classList.remove('hidden');

        const copyText = result.pixCopyPaste || JSON.stringify(result.raw);
        pixCode.textContent = copyText;
        btnCopyPix.dataset.pix = copyText;

        // Gerar QR Code
        if (result.pixCopyPaste) {
            renderQRCode(result.pixCopyPaste);
        } else if (result.qrCodeUrl) {
            document.getElementById('qr-container').innerHTML = `<div class="relative w-48 h-48"><img src="${result.qrCodeUrl}" alt="QR Code Pix" class="w-full h-full rounded-lg" /></div>`;
        } else {
            document.getElementById('qr-container').innerHTML = '<p class="text-xs text-muted-foreground">QR Code indisponível</p>';
        }

        // Iniciar polling de pagamento (5s)
        if (currentTxId) {
            startPaymentPolling(config);
        }

    } catch (err) {
        console.error('Erro ao gerar PIX:', err);
        apiErrorEl.textContent = "❌ " + (err.message || "Erro de conexão. Tente novamente.");
        apiErrorEl.classList.remove('hidden');
    } finally {
        btnGeneratePix.disabled = false;
        btnText.textContent = "Gerar Pix";
        btnLoader.classList.add('hidden');
    }
});

// ===== POLLING DE PAGAMENTO =====
async function checkPaymentStatus(config) {
    if (!currentTxId) return false;
    try {
        let res;
        switch (config.activeGateway) {
            case 'ironpay': {
                const creds = config.gateways.ironpay;
                // IronPay: consulta via ?hash= query param
                res = await fetch(`${API_BASES.ironpay}/api/public/v1/transactions?api_token=${encodeURIComponent(creds.token)}&hash=${currentTxId}`, { headers: { 'Accept': 'application/json' } });
                break;
            }
            case 'activepay': {
                const creds = config.gateways.activepay;
                const auth = 'Basic ' + btoa_utf8(creds.public_key + ':' + creds.secret_key);
                res = await fetch(`${API_BASES.activepay}/v1/transactions/${currentTxId}`, { headers: { 'Authorization': auth, 'Accept': 'application/json' } });
                break;
            }
            case 'unipay': {
                const creds = config.gateways.unipay;
                const auth = 'Basic ' + btoa_utf8('x:' + creds.secret_key);
                res = await fetch(`${API_BASES.unipay}/api/user/transactions/${currentTxId}`, { headers: { 'Authorization': auth, 'Accept': 'application/json' } });
                break;
            }
            case 'paguex': {
                const creds = config.gateways.paguex;
                const auth = 'Basic ' + btoa_utf8(creds.public_key + ':' + creds.secret_key);
                res = await fetch(`${API_BASES.paguex}/v1/payment-transaction/info/${currentTxId}`, { headers: { 'Authorization': auth, 'Accept': 'application/json' } });
                break;
            }
            case 'moonfy': {
                const creds = config.gateways.moonfy;
                const auth = 'Basic ' + btoa_utf8(creds.public_key + ':' + creds.secret_key);
                res = await fetch(`${API_BASES.moonfy}/v1/transactions/${currentTxId}`, { headers: { 'Authorization': auth, 'Accept': 'application/json' } });
                break;
            }
            case 'mangofy': {
                const creds = config.gateways.mangofy;
                res = await fetch(`${API_BASES.mangofy}/api/v1/payment/${currentTxId}`, { 
                    headers: { 
                        'Authorization': creds.api_key,
                        'Store-Code': creds.store_code,
                        'Accept': 'application/json' 
                    } 
                });
                break;
            }
            case 'otimize': {
                const creds = config.gateways.otimize;
                const auth = 'Basic ' + btoa_utf8(creds.secret_key + ':x');
                res = await fetch(`${API_BASES.otimize}/v1/transactions/${currentTxId}`, { headers: { 'Authorization': auth, 'Accept': 'application/json' } });
                break;
            }
            case 'sigilopay': {
                const creds = config.gateways.sigilopay;
                res = await fetch(`${API_BASES.sigilopay}/gateway/transactions?id=${currentTxId}`, { 
                    headers: { 
                        'x-public-key': creds.public_key,
                        'x-secret-key': creds.secret_key,
                        'Accept': 'application/json' 
                    } 
                });
                break;
            }
        }
        if (!res || !res.ok) return false;
        const data = await res.json();
        console.log('Poll status:', data);
        console.log('[Poll] Gateway:', config.activeGateway, '| Full response:', JSON.stringify(data));

        let s = '';
        if (config.activeGateway === 'ironpay') {
            // IronPay returns { data: [...transactions] } — find ours by hash
            const txList = Array.isArray(data?.data) ? data.data : [];
            const tx = txList.find(t => t.hash === currentTxId);
            s = String(tx?.payment_status || '').toLowerCase();
            console.log('[Poll] IronPay tx found:', !!tx, '| payment_status:', s);
        } else if (config.activeGateway === 'unipay') {
            // UniPay wraps with { status: 200, data: { status: "WAITING_PAYMENT" } }
            s = String(data?.data?.status || '').toLowerCase();
            console.log('[Poll] UniPay payment status:', s);
        } else if (config.activeGateway === 'mangofy') {
            s = String(data?.payment_status || data?.data?.payment_status || data?.status || '').toLowerCase();
            console.log('[Poll] Mangofy payment status:', s);
        } else if (config.activeGateway === 'otimize') {
            s = String(data?.data?.status || data?.status || '').toLowerCase();
            console.log('[Poll] Otimize payment status:', s);
        } else if (config.activeGateway === 'sigilopay') {
            s = String(data?.status || data?.data?.status || '').toLowerCase();
            console.log('[Poll] SigiloPay payment status:', s);
        } else {
            const status = data?.status || data?.data?.status || data?.Status || '';
            s = String(status).toLowerCase();
        }
        console.log('[Poll] Status detected:', s);
        return ['paid', 'approved', 'complete', 'completed'].includes(s);
    } catch (e) {
        console.log('Polling error:', e);
        return false;
    }
}

function startPaymentPolling(config) {
    if (pollingInterval) clearInterval(pollingInterval);
    const checkingEl = document.getElementById('payment-checking');
    if (checkingEl) checkingEl.classList.remove('hidden');

    pollingInterval = setInterval(async () => {
        const paid = await checkPaymentStatus(config);
        if (paid) {
            clearInterval(pollingInterval);
            if (checkingEl) checkingEl.innerHTML = '✅ <strong>Pagamento confirmado! Redirecionando...</strong>';
            // Redirect to upsell after a short delay
            setTimeout(() => {
                window.location.href = '../upsell/';
            }, 2000);
        }
    }, 5000);
}

// ===== COPIAR PIX =====
btnCopyPix.addEventListener('click', () => {
    const text = btnCopyPix.dataset.pix;
    if (!text) return;

    navigator.clipboard.writeText(text);
    btnCopyPix.textContent = "✓ Copiado!";
    btnCopyPix.classList.remove('bg-primary', 'text-primary-foreground');
    btnCopyPix.classList.add('bg-green-600', 'text-white');

    setTimeout(() => {
        btnCopyPix.textContent = "Copiar código Pix";
        btnCopyPix.classList.add('bg-primary', 'text-primary-foreground');
        btnCopyPix.classList.remove('bg-green-600', 'text-white');
    }, 2500);
});

// ===== NOTIFICAÇÃO SOCIAL PROOF =====
const notificationEl = document.getElementById('social-proof');
const spName = document.getElementById('sp-name');
const spValue = document.getElementById('sp-value');

const getRandomValue = () => {
    const min = 91.24;
    const max = 653.13;
    return (Math.random() * (max - min) + min).toFixed(2).replace(".", ",");
};

const playSound = () => {
    try {
        const windowAudioContext = window.AudioContext || window.webkitAudioContext;
        if (!windowAudioContext) return;
        const ctx = new windowAudioContext();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.frequency.value = 880;
        osc.type = "sine";
        gain.gain.setValueAtTime(0.08, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.3);
    } catch (e) { }
};

let lastIndex = -1;

const showNotification = () => {
    let index;
    do {
        index = Math.floor(Math.random() * NAMES.length);
    } while (index === lastIndex);

    lastIndex = index;
    spName.textContent = NAMES[index];
    spValue.textContent = "R$ " + getRandomValue();

    notificationEl.classList.remove('-translate-y-full', 'opacity-0');
    notificationEl.classList.add('translate-y-0', 'opacity-100');
    playSound();

    setTimeout(() => {
        notificationEl.classList.add('-translate-y-full', 'opacity-0');
        notificationEl.classList.remove('translate-y-0', 'opacity-100');
    }, 5000);
};

// Iniciar notificações
setTimeout(() => {
    showNotification();
    setInterval(showNotification, 30000);
}, 5000);

// ===== INICIALIZAR VALORES DO CARRINHO =====
(function initCartValues() {
    const config = getGatewayConfig();
    const amount = config?.product?.amount || '98,52';
    const productName = config?.product?.name || 'Feirão Serasa 2026';

    const nameEl = document.getElementById('cart-product-name');
    const descEl = document.getElementById('cart-product-desc');
    const subtotalEl = document.getElementById('cart-subtotal');
    const totalEl = document.getElementById('cart-total');

    if (nameEl) nameEl.textContent = productName;
    if (descEl) descEl.textContent = productName;
    if (subtotalEl) subtotalEl.textContent = 'R$ ' + amount;
    if (totalEl) totalEl.textContent = 'R$ ' + amount;
})();
