document.addEventListener("DOMContentLoaded", () => {
  // ===== Helpers =====
  const qs = (s, r = document) => r.querySelector(s);
  const BRL = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
  function amountToCents(amountStr) {
    const clean = String(amountStr).replace(/[^\d,\.]/g, '').replace(',', '.');
    return Math.round(parseFloat(clean) * 100);
  }

  // ===== UTM tracking =====
  function persistUTMs() {
    const params = new URLSearchParams(window.location.search);
    let utms = JSON.parse(localStorage.getItem('ft_utms') || '{}');
    let updated = false;
    ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'src', 'sck'].forEach(p => {
      if (params.has(p)) { utms[p] = params.get(p); updated = true; }
    });
    if (updated) localStorage.setItem('ft_utms', JSON.stringify(utms));
  }
  persistUTMs();

  // ===== Restore Customer Data =====
  let checkoutData = { nome: '', email: '', cpf: '', whatsapp: '' };
  try {
    const stored = localStorage.getItem('checkout_data');
    if (stored) checkoutData = JSON.parse(stored);
  } catch (e) { }

  // ===== LOAD CHECKOUT SCRIPT DATA se faltar dados =====
  if (!checkoutData.cpf || !checkoutData.whatsapp) {
    try {
      const stored2 = localStorage.getItem('checkout_customer');
      if (stored2) {
        const c2 = JSON.parse(stored2);
        if (c2.document && !checkoutData.cpf) checkoutData.cpf = c2.document;
        if (c2.phone && !checkoutData.whatsapp) checkoutData.whatsapp = c2.phone;
        if (c2.name && !checkoutData.nome) checkoutData.nome = c2.name;
        if (c2.email && !checkoutData.email) checkoutData.email = c2.email;
      }
    } catch (e) { }
  }

  // ===== UI Effects =====
  setTimeout(() => {
    qs('#loader').style.opacity = '0';
    qs('#content').classList.remove('opacity-0', 'pointer-events-none', 'select-none');
    setTimeout(() => qs('#loader').style.display = 'none', 300);
  }, 1800);

  const canvas = document.getElementById('confetti-canvas');
  if (canvas && typeof confetti !== 'undefined') {
    let W = canvas.width = window.innerWidth;
    let H = canvas.height = window.innerHeight;
    const ctx = canvas.getContext('2d');
    const particles = Array.from({ length: 60 }).map(() => ({
      x: Math.random() * W, y: Math.random() * H - H,
      r: Math.random() * 4 + 2,
      dx: Math.random() * 2 - 1, dy: Math.random() * 3 + 2,
      c: ['#E1187D', '#BE1166', '#F5821F', '#FFD100'][Math.floor(Math.random() * 4)]
    }));
    let start = null;
    const durationMs = 3000;
    const tick = (ts) => {
      if (!start) start = ts;
      const elapsed = ts - start;
      ctx.clearRect(0, 0, W, H);
      particles.forEach(p => {
        p.x += p.dx; p.y += p.dy;
        if (p.y > H) { p.y = -10; p.x = Math.random() * W; }
        ctx.beginPath();
        ctx.fillStyle = p.c;
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      });
      if (elapsed < durationMs) requestAnimationFrame(tick);
      else ctx.clearRect(0, 0, W, H);
    };
    requestAnimationFrame(tick);
    window.addEventListener('resize', () => {
      W = canvas.width = window.innerWidth;
      H = canvas.height = window.innerHeight;
    }, { passive: true });
  }

  // ===== GATEWAY UNIFICADO ICM =====
  function getGatewayConfig() {
    if (typeof GLOBAL_CONFIG !== 'undefined') {
      return GLOBAL_CONFIG;
    }
    return null;
  }

  function btoa_utf8(str) { return btoa(unescape(encodeURIComponent(str))); }

  const config = getGatewayConfig();
  const amountStr = config?.icm?.amount || '38,50';
  const amountCents = amountToCents(amountStr);
  const titleName = config?.icm?.name || 'Pagamento recebido';

  if (qs('#icm-tax-value')) qs('#icm-tax-value').textContent = 'R$ ' + amountStr;
  if (qs('#icm-main-value')) qs('#icm-main-value').textContent = 'R$ ' + amountStr;
  if (qs('#btn-value')) qs('#btn-value').textContent = 'R$ ' + amountStr;
  if (qs('#icm-heading')) qs('#icm-heading').textContent = titleName;

  async function createPixIronPay(config, customer, amountCents, productName) {
    const creds = config.gateways.ironpay;
    if (!creds.offer_hash || !creds.product_hash) throw new Error('IronPay requer Offer Hash e Product Hash.');
    const url = `${API_BASES.ironpay}/api/public/v1/transactions?api_token=${encodeURIComponent(creds.token)}`;
    const body = {
      amount: amountCents,
      offer_hash: creds.offer_hash,
      payment_method: "pix",
      customer: {
        name: customer.name,
        email: customer.email,
        phone_number: customer.phone,
        document: customer.cpf,
        street_name: "Rua Principal",
        number: "1",
        complement: "",
        neighborhood: "Centro",
        city: "São Paulo",
        state: "SP",
        zip_code: "01001000"
      },
      cart: [{
        product_hash: creds.product_hash,
        title: productName,
        cover: null,
        price: amountCents,
        quantity: 1,
        operation_type: 1,
        tangible: false
      }],
      expire_in_days: 1,
      transaction_origin: "api"
    };
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify(body)
    });
    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.message || `Erro IronPay: ${response.status}`);
    }
    const data = await response.json();
    console.log('IronPay response:', data);
    let pixCopyPaste = data?.pix?.pix_qr_code || data?.pix?.qrcode || data?.pix?.qr_code || data?.qrcode || null;
    let qrCodeUrl = data?.pix?.pix_url || data?.pix?.qr_code_url || null;
    return { pixCopyPaste, qrCodeUrl, raw: data };
  }

  async function createPixActivePay(config, customer, amountCents, productName) {
    const creds = config.gateways.activepay;
    const auth = 'Basic ' + btoa_utf8(creds.public_key + ':' + creds.secret_key);
    const body = {
      amount: amountCents,
      paymentMethod: "pix",
      customer: {
        name: customer.name,
        email: customer.email,
        phone: customer.phone,
        document: {
          number: customer.cpf,
          type: "cpf"
        }
      },
      items: [{
        title: productName,
        unitPrice: amountCents,
        quantity: 1,
        tangible: false,
        externalRef: "checkout-pix"
      }],
      pix: {
        expiresInDays: 1
      }
    };
    const response = await fetch(`${API_BASES.activepay}/v1/transactions`, {
      method: 'POST',
      headers: { 'Authorization': auth, 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify(body)
    });
    if (!response.ok) {
      let errData = {};
      try { errData = await response.json(); } catch (e) { }
      console.error('ActivePay Error Detail:', errData);
      throw new Error(errData.message ? `${errData.message} | Detalhes: ${JSON.stringify(errData)}` : `Erro ActivePay: ${response.status}`);
    }
    const data = await response.json();
    console.log('ActivePay response:', data);
    let pixCopyPaste = null;
    let qrCodeUrl = null;
    if (data.data && data.data.pix && data.data.pix.qrcode) {
      pixCopyPaste = data.data.pix.qrcode;
    } else if (data.pix && data.pix.qrcode) {
      pixCopyPaste = data.pix.qrcode;
    } else if (data.qrcode) {
      pixCopyPaste = data.qrcode;
    }
    return { pixCopyPaste, qrCodeUrl, raw: data };
  }

  async function createPixUniPay(config, customer, amountCents, productName) {
    const creds = config.gateways.unipay;
    const auth = 'Basic ' + btoa_utf8('x:' + creds.secret_key);
    const body = {
      amount: amountCents,
      paymentMethod: "PIX",
      customer: {
        name: customer.name,
        email: customer.email,
        phone: customer.phone,
        document: {
          number: customer.cpf,
          type: "CPF"
        }
      },
      items: [{
        title: productName,
        unitPrice: amountCents,
        quantity: 1,
        tangible: false,
        externalRef: "checkout-pix"
      }],
      pix: {
        expiresInDays: 1
      },
      traceable: true
    };
    const response = await fetch(`${API_BASES.unipay}/api/user/transactions`, {
      method: 'POST',
      headers: { 'Authorization': auth, 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify(body)
    });
    if (!response.ok) {
      let errData = {};
      try { errData = await response.json(); } catch (e) { }
      console.error('FATAL UNIPAY API ERROR RESPONSE:', JSON.stringify(errData, null, 2));
      throw new Error(errData.message ? `${errData.message} | Detalhes: ${JSON.stringify(errData)}` : `Erro UniPay: ${response.status}`);
    }
    const data = await response.json();
    console.log('UniPay response:', data);
    let pixCopyPaste = null;
    let qrCodeUrl = null;
    if (data.data && data.data.pix && data.data.pix.qrcode) {
      pixCopyPaste = data.data.pix.qrcode;
    } else if (data.pix && data.pix.qrcode) {
      pixCopyPaste = data.pix.qrcode;
    } else if (data.qrcode) {
      pixCopyPaste = data.qrcode;
    }
    return { pixCopyPaste, qrCodeUrl, raw: data };
  }

  async function createPixPagueX(config, customer, amountCents, productName) {
    const creds = config.gateways.paguex;
    const auth = 'Basic ' + btoa_utf8(creds.public_key + ':' + creds.secret_key);
    const body = {
      amount: amountCents, payment_method: "pix",
      postback_url: "https://webhook.site/paguex-postback",
      customer: { name: customer.name, email: customer.email, phone: customer.phone, document: { number: customer.cpf, type: "cpf" } },
      items: [{ title: productName, unit_price: amountCents, quantity: 1, tangible: false, external_ref: "icm-pix" }],
      pix: { expires_in_days: 1 },
      metadata: { provider_name: "icm" }
    };
    const response = await fetch(`${API_BASES.paguex}/v1/payment-transaction/create`, {
      method: 'POST', headers: { 'Authorization': auth, 'Content-Type': 'application/json', 'Accept': 'application/json' }, body: JSON.stringify(body)
    });
    if (!response.ok) { let e = {}; try { e = await response.json(); } catch (_) { } throw new Error(e.message || `Erro PagueX: ${response.status}`); }
    const data = await response.json();
    console.log('PagueX response:', data);
    let pixCopyPaste = null, qrCodeUrl = null;
    if (data?.data?.pix?.qr_code) { pixCopyPaste = data.data.pix.qr_code; qrCodeUrl = data.data.pix.url || null; }
    else if (data?.pix?.qr_code) { pixCopyPaste = data.pix.qr_code; }
    return { pixCopyPaste, qrCodeUrl, raw: data };
  }

  async function createPixMoonfy(config, customer, amountCents, productName) {
    const creds = config.gateways.moonfy;
    const auth = 'Basic ' + btoa_utf8(creds.public_key + ':' + creds.secret_key);
    const body = {
      amount: amountCents, paymentMethod: "pix",
      customer: { name: customer.name, email: customer.email, phone: customer.phone, document: { number: customer.cpf, type: "cpf" } },
      items: [{ title: productName, unitPrice: amountCents, quantity: 1, tangible: false, externalRef: "icm-pix" }],
      pix: { expiresInDays: 1 }
    };
    const response = await fetch(`${API_BASES.moonfy}/v1/transactions`, {
      method: 'POST', headers: { 'Authorization': auth, 'Content-Type': 'application/json', 'Accept': 'application/json' }, body: JSON.stringify(body)
    });
    if (!response.ok) { let e = {}; try { e = await response.json(); } catch (_) { } throw new Error(e.message || `Erro Moonfy: ${response.status}`); }
    const data = await response.json();
    console.log('Moonfy response:', data);
    let pixCopyPaste = data?.data?.pix?.qrcode || data?.pix?.qrcode || data?.qrcode || null;
    return { pixCopyPaste, qrCodeUrl: null, raw: data };
  }

  async function createPixMangofy(config, customer, amountCents, productName) {
    const creds = config.gateways.mangofy;
    let clientIp = '0.0.0.0';
    try { const r = await fetch('https://api.ipify.org?format=json'); const d = await r.json(); clientIp = d.ip || '0.0.0.0'; } catch (e) { }
    const body = {
      store_code: creds.store_code,
      payment_method: "pix",
      payment_format: "upsell",
      installments: 1,
      payment_amount: amountCents,
      items: [{ title: productName, unit_price: amountCents, quantity: 1, tangible: false, external_ref: "icm-pix" }],
      customer: { name: customer.name, email: customer.email, phone: customer.phone, document: customer.cpf, ip: clientIp },
      pix: { expires_in_days: 1 },
      postback_url: "https://webhook.site/mangofy-postback",
      external_code: "icm-" + Date.now()
    };
    const response = await fetch(`${API_BASES.mangofy}/api/v1/payment`, {
      method: 'POST',
      headers: {
        'Authorization': creds.api_key, 'Store-Code': creds.store_code,
        'Content-Type': 'application/json', 'Accept': 'application/json'
      },
      body: JSON.stringify(body)
    });
    if (!response.ok) { let e = {}; try { e = await response.json(); } catch (_) { } throw new Error(e.message || `Erro Mangofy: ${response.status}`); }
    const resp_json = await response.json();
    const data = resp_json.data || resp_json;
    console.log('Mangofy response:', resp_json);
    let pixCopyPaste = null, qrCodeUrl = null;
    if (data.pix?.pix_qrcode_text) pixCopyPaste = data.pix.pix_qrcode_text;
    else if (data.pix?.qrcode_text) pixCopyPaste = data.pix.qrcode_text;
    else if (data.pix_qrcode) pixCopyPaste = data.pix_qrcode;
    else if (data.pix?.qrcode) pixCopyPaste = data.pix.qrcode;
    else if (data.qrcode) pixCopyPaste = data.qrcode;
    else if (data.qr_code) pixCopyPaste = data.qr_code;
    else if (data.pix?.qr_code) pixCopyPaste = data.pix.qr_code;
    return { pixCopyPaste, qrCodeUrl, raw: resp_json };
  }

  async function createPixOtimize(config, customer, amountCents, productName) {
    const creds = config.gateways.otimize;
    const auth = 'Basic ' + btoa_utf8(creds.secret_key + ':x');
    const body = {
      amount: amountCents, paymentMethod: "pix",
      customer: { name: customer.name, email: customer.email, phone: customer.phone, document: { number: customer.cpf, type: "cpf" } },
      items: [{ title: productName, unitPrice: amountCents, quantity: 1, tangible: false, externalRef: "icm-pix" }],
      pix: { expiresInDays: 1 }
    };
    const response = await fetch(`${API_BASES.otimize}/v1/transactions`, {
      method: 'POST', headers: { 'Authorization': auth, 'Content-Type': 'application/json', 'Accept': 'application/json' }, body: JSON.stringify(body)
    });
    if (!response.ok) { let e = {}; try { e = await response.json(); } catch (_) { } throw new Error(e.message || `Erro Otimize: ${response.status}`); }
    const data = await response.json();
    console.log('Otimize response:', data);
    let pixCopyPaste = data?.data?.pix?.qrcode || data?.pix?.qrcode || data?.data?.pix?.qr_code || data?.qrcode || null;
    return { pixCopyPaste, qrCodeUrl: null, raw: data };
  }

  function extractPixCode(data) {
    return data?.pixCopyPaste || data?.pix?.pix_qr_code || data?.data?.pix?.qrcode || data?.pix?.qrcode || data?.pix?.qr_code || data?.qrcode || data?.data?.qrcode || null;
  }
  function extractTransactionId(data, gateway) {
    if (data?.raw) {
      const raw = data.raw;
      if (gateway === 'ironpay') return raw?.hash || raw?.data?.hash || raw?.id || raw?.data?.id;
      if (gateway === 'activepay') return raw?.data?.id || raw?.id || raw?.data?.secureId;
      if (gateway === 'unipay') return raw?.data?.id || raw?.id;
      if (gateway === 'paguex') return raw?.data?.id || raw?.Id || raw?.id;
      if (gateway === 'moonfy') return raw?.data?.id || raw?.id;
      if (gateway === 'mangofy') return raw?.payment_code || raw?.id;
      if (gateway === 'otimize') return raw?.data?.id || raw?.id;
    }
    if (gateway === 'ironpay') return data?.hash || data?.data?.hash || data?.id || data?.data?.id;
    if (gateway === 'activepay') return data?.data?.id || data?.id || data?.data?.secureId;
    if (gateway === 'unipay') return data?.data?.id || data?.id;
    if (gateway === 'paguex') return data?.data?.id || data?.Id || data?.id;
    if (gateway === 'moonfy') return data?.data?.id || data?.id;
    if (gateway === 'mangofy') return data?.payment_code || data?.id;
    if (gateway === 'otimize') return data?.data?.id || data?.id;
    return null;
  }

  let currentTxId = null;
  let pollingInterval = null;

  const btnPay = qs('#btn-gerar-pix');
  if (btnPay) {
    btnPay.addEventListener('click', async function () {
      if (!config || !config.activeGateway) return showError('Nenhum gateway configurado.');

      btnPay.disabled = true;
      btnPay.innerHTML = 'Gerando Pix...';

      const customerData = JSON.parse(localStorage.getItem('checkout_customer') || '{}');
      if (!customerData.name) {
        customerData.name = checkoutData.nome || 'Cliente';
        customerData.email = checkoutData.email || 'cliente@email.com';
        customerData.cpf = (checkoutData.cpf || '52998224725').replace(/\D/g, '');
        customerData.phone = (checkoutData.whatsapp || '11999999999').replace(/\D/g, '');
      }

      try {
        let rawData;
        // REQUISITO: O nome do produto deste 3º upsell deve ser enviado como "Produto 4"
        switch (config.activeGateway) {
          case 'ironpay': rawData = await createPixIronPay(config, customerData, amountCents, "Produto 4"); break;
          case 'activepay': rawData = await createPixActivePay(config, customerData, amountCents, "Produto 4"); break;
          case 'unipay': rawData = await createPixUniPay(config, customerData, amountCents, "Produto 4"); break;
          case 'paguex': rawData = await createPixPagueX(config, customerData, amountCents, "Produto 4"); break;
          case 'moonfy': rawData = await createPixMoonfy(config, customerData, amountCents, "Produto 4"); break;
          case 'mangofy': rawData = await createPixMangofy(config, customerData, amountCents, "Produto 4"); break;
          case 'otimize': rawData = await createPixOtimize(config, customerData, amountCents, "Produto 4"); break;
        }

        const pixCode = extractPixCode(rawData);
        currentTxId = extractTransactionId(rawData, config.activeGateway);

        if (!pixCode) throw new Error('Não foi possível gerar código PIX.');

        btnPay.style.display = 'none';
        qs('#pix-section').style.display = 'flex';
        qs('#pix-code').textContent = pixCode;

        try {
          new QRCode(qs('#qr-wrap'), { text: pixCode, width: 192, height: 192, colorDark: "#000", colorLight: "#fff", correctLevel: QRCode.CorrectLevel.M });
        } catch (e) {
          qs('#qr-wrap').innerHTML = `<img src="https://api.qrserver.com/v1/create-qr-code/?size=192x192&data=${encodeURIComponent(pixCode)}" style="width:192px;height:192px;border-radius:8px;" />`;
        }

        if (currentTxId) {
          qs('#checking-payment').style.display = 'flex';
          startPolling(config);
        }

      } catch (e) {
        showError('Erro: ' + e.message);
        btnPay.disabled = false;
        btnPay.innerHTML = `Pagar taxa agora (PIX R$ ${amountStr})`;
      }
    });
  }

  window.copyPixCode = function () {
    const btnCopy = qs('#btn-copy');
    const text = qs('#pix-code').textContent;
    navigator.clipboard.writeText(text);
    if (btnCopy) {
      btnCopy.textContent = '✓ Copiado!';
      btnCopy.style.background = '#22c55e';
      setTimeout(() => { btnCopy.textContent = 'Copiar código Pix'; btnCopy.style.background = '#E1187D'; }, 2500);
    }
  };

  function showError(msg) {
    const el = qs('#error-msg');
    if (el) { el.textContent = msg; el.style.display = 'block'; }
    else alert(msg);
  }

  async function checkPaymentStatus(config) {
    if (!currentTxId) return false;
    try {
      let res, data;
      if (config.activeGateway === 'ironpay') {
        res = await fetch(`${API_BASES.ironpay}/api/public/v1/transactions?api_token=${encodeURIComponent(config.gateways.ironpay.token)}&hash=${currentTxId}`, { headers: { 'Accept': 'application/json' } });
      } else if (config.activeGateway === 'activepay') {
        res = await fetch(`${API_BASES.activepay}/v1/transactions/${currentTxId}`, { headers: { 'Authorization': 'Basic ' + btoa_utf8(config.gateways.activepay.public_key + ':' + config.gateways.activepay.secret_key), 'Accept': 'application/json' } });
      } else if (config.activeGateway === 'unipay') {
        res = await fetch(`${API_BASES.unipay}/api/user/transactions/${currentTxId}`, { headers: { 'Authorization': 'Basic ' + btoa_utf8('x:' + config.gateways.unipay.secret_key), 'Accept': 'application/json' } });
      } else if (config.activeGateway === 'paguex') {
        res = await fetch(`${API_BASES.paguex}/v1/payment-transaction/info/${currentTxId}`, { headers: { 'Authorization': 'Basic ' + btoa_utf8(config.gateways.paguex.public_key + ':' + config.gateways.paguex.secret_key), 'Accept': 'application/json' } });
      } else if (config.activeGateway === 'moonfy') {
        res = await fetch(`${API_BASES.moonfy}/v1/transactions/${currentTxId}`, { headers: { 'Authorization': 'Basic ' + btoa_utf8(config.gateways.moonfy.public_key + ':' + config.gateways.moonfy.secret_key), 'Accept': 'application/json' } });
      } else if (config.activeGateway === 'mangofy') {
        res = await fetch(`${API_BASES.mangofy}/api/v1/payment/${currentTxId}`, { headers: { 'Authorization': config.gateways.mangofy.api_key, 'Store-Code': config.gateways.mangofy.store_code, 'Accept': 'application/json' } });
      } else if (config.activeGateway === 'otimize') {
        const auth = 'Basic ' + btoa_utf8(config.gateways.otimize.secret_key + ':x');
        res = await fetch(`${API_BASES.otimize}/v1/transactions/${currentTxId}`, { headers: { 'Authorization': auth, 'Accept': 'application/json' } });
      }
      if (!res || !res.ok) return false;
      data = await res.json();
      console.log('Poll status:', data);
      console.log('[Poll] Gateway:', config.activeGateway, '| Full response:', JSON.stringify(data));

      let s = '';
      if (config.activeGateway === 'ironpay') {
        const txList = Array.isArray(data?.data) ? data.data : [];
        const tx = txList.find(t => t.hash === currentTxId);
        s = String(tx?.payment_status || '').toLowerCase();
        console.log('[Poll] IronPay tx found:', !!tx, '| payment_status:', s);
      } else if (config.activeGateway === 'unipay') {
        s = String(data?.data?.status || '').toLowerCase();
        console.log('[Poll] UniPay payment status:', s);
      } else if (config.activeGateway === 'mangofy') {
        s = String(data?.payment_status || data?.data?.payment_status || data?.status || '').toLowerCase();
      } else if (config.activeGateway === 'otimize') {
        s = String(data?.data?.status || data?.status || '').toLowerCase();
      } else {
        const status = data?.status || data?.data?.status || data?.Status || '';
        s = String(status).toLowerCase();
      }
      console.log('[Poll] Status detected:', s);
      return ['paid', 'approved', 'complete', 'completed'].includes(s);
    } catch (e) { return false; }
  }

  function startPolling(config) {
    if (pollingInterval) clearInterval(pollingInterval);
    pollingInterval = setInterval(async () => {
      const paid = await checkPaymentStatus(config);
      if (paid) {
        clearInterval(pollingInterval);
        window.location.href = '../iphone/index.html';
      }
    }, 5000);
  }
});